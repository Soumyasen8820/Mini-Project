﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for TicketBooking.xaml
    /// </summary>

    public partial class TicketBooking : Window
    {
        public TicketBooking()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "travel.booking_161719";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            

            cmd.Parameters.AddWithValue("@requestDate", dataPicker.Text);
            cmd.Parameters.AddWithValue("@FromLocation", cmbFromLocation.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@ToLocation", cmbToLocation.Text);
            cmd.Parameters.AddWithValue("@UserId", txtUserId.Text);

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                MessageBox.Show("Details Submitted! wait for the confirmation");
            }
            else
            {
                MessageBox.Show("Details not matched");
            }
            con.Close();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var item in Enum.GetValues(typeof(FromLocation)))
            {
                cmbFromLocation.Items.Add(item);
            }
            foreach (var item in Enum.GetValues(typeof(ToLocation)))
            {
                cmbToLocation.Items.Add(item);
            }
        }

        private void CmbToLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CmbFromLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
    enum FromLocation
        {
            Hyderabad, Pune, Bangalore, Chennai, Mumbai
        }
        enum ToLocation
        {
            Hyderabad, Pune, Bangalore, Chennai, Mumbai
        }
    
}
