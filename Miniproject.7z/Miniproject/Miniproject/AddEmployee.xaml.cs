﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Miniproject
{
    /// <summary>
    /// Interaction logic for AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "mini.addEmployee";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.Add("@EmployeeId", SqlDbType.Int);
            cmd.Parameters["@EmployeeId"].Direction = ParameterDirection.Output;
            cmd.Parameters.AddWithValue("@Firstname", txtFname.Text);
            cmd.Parameters.AddWithValue("@Lastname", txtLname.Text);
            cmd.Parameters.AddWithValue("@Age", txtAge.Text);
            cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
            cmd.Parameters.AddWithValue("@AddressofEmp",txtAddress.Text);
            cmd.Parameters.AddWithValue("@ManagerId", txtmanagerId.Text);
            cmd.Parameters.AddWithValue("@uname", txtuname.Text);
            cmd.Parameters.AddWithValue("@password", txtpass.Text);
            int s=cmd.ExecuteNonQuery();
            MessageBox.Show("Employee added");
            con.Close();
        }
    }
}
